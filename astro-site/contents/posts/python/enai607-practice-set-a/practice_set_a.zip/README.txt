ENAI607 비공식 연습문제 Set A 풀이

파일을 같은 폴더에 풀고 해당 폴더에서 실행하세요.

python problem_1.py sensor_data.txt
python problem_1.py sensor_data_extra.txt
python problem_2.py
python problem_3.py
python test_practice.py

필요 패키지: NumPy, Matplotlib (문제 3 및 전체 테스트)
설치: python -m pip install numpy matplotlib

problem_1.py는 코드 옆에 summary.txt를 씁니다(재실행 시 덮어씀).
problem_3.py는 코드 옆에 simulation.png를 저장하고 그림 창을 띄웁니다.
출력 숫자·개수만 맞추지 말고 원문의 지정 문법도 확인하세요.
