ENAI607 Set B 비공식 연습문제 풀이

모든 .py 파일을 같은 폴더에 두세요.

문제 4: python test_strings.py
문제 5 게임: python tournament.py
문제 5 테스트: python test_tournament.py
문제 6: python matrix_diagnostics.py
문제 6 테스트: python test_matrix.py

문제 6에는 numpy와 matplotlib이 필요합니다.
설치: python -m pip install numpy matplotlib

my_strings.py만 실행하면 함수 정의만 하므로 출력이 없습니다.
matrix_diagnostics.py는 첫 그림 창을 닫으면 두 번째 그림 창을 표시합니다.
PNG 두 개는 코드 파일 옆에 저장합니다.

주석의 [P4.2-B] 등은 문제 요구사항과 풀이 해설을 연결하는 표시입니다.
